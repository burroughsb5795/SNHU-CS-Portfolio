package com.example.weightlossapp;

public class Weight {
    private String weight;
    private String date;

    public Weight(String weight, String date){
        this.weight = weight;
        this.date = date;
    }

    public String getWeight(){
        return weight;
    }

    public String getDate(){
        return date;
    }
}
