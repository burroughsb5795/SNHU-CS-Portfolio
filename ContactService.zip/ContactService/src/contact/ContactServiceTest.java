package contact;

import static org.junit.Assert.assertEquals;

import org.junit.Test;


public class ContactServiceTest {
	@Test 
	public void testAdd() {
		ContactService service = new ContactService();
		Contact test1 = new Contact("1234567", "Bryce", "Burroughs", "123456789", "123 Address Drive");
		assertEquals(true, service.addContact(test1));
	}
	
	@Test
	public void testDelete() {
		ContactService service = new ContactService();
		Contact test1 = new Contact("1234567", "Bryce", "Burroughs", "1234567890", "123 Address Drive");
		Contact test2 = new Contact("1111111", "John", "Doe", "1231231023", "123 Address Street");
		Contact test3 = new Contact("1231231", "Jane", "Doe", "1111111101", "123 Street Drive");
		
		service.addContact(test1);
		service.addContact(test2);
		service.addContact(test3);
		
		assertEquals(true, service.deleteContact("1111111"));
		assertEquals(false, service.deleteContact("1111112"));
		assertEquals(false, service.deleteContact("1111111"));
	}
	
	@Test 
	public void testUpdate() {
		ContactService service = new ContactService();
		
		Contact test1 = new Contact("1234567", "Bryce", "Burroughs", "1234567890", "123 Address Drive");
		Contact test2 = new Contact("1111111", "John", "Doe", "1231231230", "123 Address Street");
		Contact test3 = new Contact("1231231", "Jane", "Doe", "1111111110", "123 Street Drive");
		
		service.addContact(test1);
		service.addContact(test2);
		service.addContact(test3);
		
		assertEquals(true, service.updateContact("1231231", "New", "Last", "1234567670", "New Address"));
		assertEquals(false, service.updateContact("1112321", "New", "Last", "12345565605", "New New"));
		
	}

}
