package contact;

import java.util.ArrayList;


public class ContactService {
	private ArrayList<Contact> contacts;
	
	public ContactService() {
		contacts = new ArrayList<>();
	}
	
	public boolean addContact(Contact contact) {
		boolean contactExists = false;
		for (Contact contactList:contacts) {
			if (contactList.equals(contact)) {
				contactExists = true;
			}
		}
		if (!contactExists) {
			contacts.add(contact);
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean deleteContact(String contactID) {
		for (Contact contactList:contacts) {
			if(contactList.getContactID().equals(contactID)) {
				contacts.remove(contactList);
			}
		}
		return false;
	}
	
	public boolean updateContact(String contactID, String firstName, String lastName, String phoneNum, String address) {
		for (Contact contactList:contacts) {
			if (contactList.getContactID().equals(contactID)) {
				if(!firstName.equals("") && !(firstName.length()>10)) {
					contactList.setFirstName(firstName);
				}
				if(!lastName.equals("") && !(lastName.length()>10)) {
					contactList.setLastName(lastName);
				}
				if(!phoneNum.equals("") && !(phoneNum.length()==10)) {
					contactList.setPhoneNum(phoneNum);
				}
				if(!address.equals("") && !(address.length()>30)) {
					contactList.setAddress(address);
				}
				return true;
			}
		}
		return false;
	}
}
