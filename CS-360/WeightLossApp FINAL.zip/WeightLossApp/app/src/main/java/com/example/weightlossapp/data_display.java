package com.example.weightlossapp;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.Calendar;


public class data_display extends AppCompatActivity {
    private RecyclerView recyclerView;
    private FloatingActionButton addbutton, deleteButton;

    private Button dateButton;

    private EditText weightInput;
    private WeightAdapter weightAdapter;
    private ArrayList<Weight> weightList;
    private DatabaseHelper databaseHelper;

    private String selectedDate = "No Date Selected"; //init value for date
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        databaseHelper = new DatabaseHelper(this);

        recyclerView = findViewById(R.id.recyclerView);
        addbutton = findViewById(R.id.add_data_button);
        deleteButton = findViewById(R.id.delete_button);
        weightInput = findViewById(R.id.textView4);
        dateButton = findViewById(R.id.date_select);

        weightList = new ArrayList<>();
        weightAdapter = new WeightAdapter(weightList);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(weightAdapter);

        addbutton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String weight = weightInput.getText().toString();
                if (!weight.isEmpty()){
                    Weight newWeight = new Weight(weight, selectedDate);
                    weightList.add(newWeight);
                    weightAdapter.notifyDataSetChanged();
            } else {
                    Toast.makeText(data_display.this, "Please eneter weight", Toast.LENGTH_SHORT).show();
                }
            }
        });
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!weightList.isEmpty()){
                    weightList.remove(weightList.size() - 1);
                    weightAdapter.notifyDataSetChanged();
                } else{
                    Toast.makeText(data_display.this, "No data to delete", Toast.LENGTH_SHORT).show();
                }
            }
        });

        dateButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                showCalendar();
            }
        });
    }
    private void showCalendar(){
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePicker = new DatePickerDialog(
                data_display.this,
                (view, year1, month1, dayOfMonth ) -> {
                    selectedDate = (month1 + 1) + "/" + dayOfMonth + "/" + year1;
                    Toast.makeText(data_display.this, "Selected Date: " + selectedDate, Toast.LENGTH_SHORT).show();
                },
                year, month, day);
        datePicker.show();
    }
}