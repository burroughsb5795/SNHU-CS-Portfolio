package com.example.weightlossapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {
    private ArrayList<Weight>  weightList;

    public WeightAdapter(ArrayList<Weight> weightList){
        this.weightList = weightList;
    }

    @NonNull
    @Override

    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.weight_item, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position){
        Weight weight = weightList.get(position);
        holder.weightTextView.setText(weight.getWeight());
        holder.dateTextView.setText(weight.getDate());
    }

    @Override
    public int getItemCount(){
        return weightList.size();
    }

    public static class WeightViewHolder extends RecyclerView.ViewHolder {
        TextView weightTextView, dateTextView;

        public WeightViewHolder(@NonNull View itemView){
            super(itemView);
            weightTextView = itemView.findViewById(R.id.weightTextView);
            dateTextView = itemView.findViewById(R.id.dateTextView);
        }
    }
}
